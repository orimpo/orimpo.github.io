package URI::_foreign;

require URI::_generic;
@ISA=qw(URI::_generic);

1;
