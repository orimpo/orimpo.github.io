#!/usr/bin/perl

use ex::lib '../lib';

use tdebug; # from here we see debug messages
use tnodebug; # and from here we not

