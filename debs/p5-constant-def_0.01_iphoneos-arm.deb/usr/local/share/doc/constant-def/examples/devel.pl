#!/usr/bin/perl

use ex::lib '../lib';

# redefine constant in tnodebug to see diagnostics warnings
use constant::abs 'tnodebug::DEBUG' => 1;

use tdebug;
use tnodebug;

